"Resource/HudLayout.res"
{
"Fixture" { "visible" "1" }
}
